// const express = require("express");
import express from "express";
import productRoute from "./routes/productRoute.js";
import userRoute from "./routes/userRoute.js";
import orderRoute from "./routes/orderRoutes.js";
import paymentRoute from "./routes/paymentRoute.js";
import bodyParser from "body-parser";
import cookieParser from "cookie-parser";
import cors from "cors";
import errorMiddleware from "./middleware/error.js";
import fileUpload from "express-fileupload";
import dotenv from "dotenv";

dotenv.config({ path: "backend/config/config.env" });

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);
app.use(fileUpload());
app.use(cookieParser());
app.use("/api/v1", productRoute);
app.use("/api/v1", userRoute);
app.use("/api/v1", orderRoute);
app.use("/api/v1", paymentRoute);

// Middleware for error
app.use(errorMiddleware);

export default app;

// body-parser deprecated undefined extended: provide extended option file
